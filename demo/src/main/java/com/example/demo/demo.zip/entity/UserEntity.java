package com.example.demo.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.example.demo.dto.request.auth.SignUpRequestDto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter //변수들getter생성
@NoArgsConstructor  //매개변수가 없는 생성자 자동으로 만들어줌
@AllArgsConstructor  //지정하는 모든 필드에 대해 생성자 만들어줌
@Entity(name="customer")
@Table(name="customer")
public class UserEntity {

    @Id//userId:pk지정
    @Column(name="user_id")//컬럼명 정해줌
    private int userId;
    private String email;
    private String password;
    @Column(name="phone_number")
    private String phoneNumber;
    private String name;
    private String nickname;
    @Column(name="registration_date")
    private LocalDateTime registrationDate;
    private String status;
    private String role;

    public UserEntity (SignUpRequestDto dto){
        this.userId = dto.getId();
        this.password = dto.getPassword();
        this.email = dto.getEmail();
        this.phoneNumber ="000-7687-9313";
        this.name="윤선호";
        this.nickname="샐리";
        this.registrationDate = LocalDateTime.now();
        this.status = "active";
        this.role = "ROLE_USER";
    }
}

import React, { useEffect, useState } from 'react';
import './wishes.css'
import movie1 from '../assets/notebook.jpg'
import movie2 from '../assets/ping.jpg'
import movie3 from '../assets/killers.jpg'
import movie4 from '../assets/ordrey.jpg'
import {
    FcLikePlaceholder,
    FcLike
}from 'react-icons/fc'
import axios from 'axios';


const Wishes = ({userId}) => {

    const [isLiked, setIsLiked] = useState(false);

    const handleClick = () => {
        setIsLiked(!isLiked);
      };

      const [wishlistMovies, setWishlistMovies] = useState([]);

      useEffect(() => {
        const fetchWishlistMovies = async () => {
          try {
            const response = await axios.get(`/api/wishlist/${userId}`);
            setWishlistMovies(response.data);
          } catch (error) {
            console.error('위시리스트 영화 정보를 가져오는 데 실패했습니다:', error);
          }
        };
    
        fetchWishlistMovies();
      }, [userId]);

    return (
        <>
            <div >
                <div className='mypage_wrap'>
                    <div className='title_sub_area'>
                        <div className='left_area'>
                            <h1 className="title">내가 보고 싶은 영화</h1>
                            <span className="sub"><em>3</em> 편</span>
                        </div>
                    </div>
                    <ul className='my_movie_list'>
                    <li style={{display: 'block'}}>
                        <div className='poster' style={{cursor: 'pointer'}}>
                        <a href="#none"><img src={movie1} alt="" style={{ width: '100%', height: 'auto' }} /></a>
                        </div>
                        <strong className='tit' style={{cursor: 'pointer'}}>
                            <span className='ic_grade gr_15'></span>
                            &nbsp;
                            노트북
                        </strong>
                        <div className='detail_info ty1'>
                        <i onClick={() => { handleClick() }} >
                            {isLiked 
                                ? <FcLike style={{ width: '20px', height: '20px' }}/> 
                                : <FcLikePlaceholder style={{ width: '20px', height: '20px' }}/>}
                        </i>
                        </div>
                        <dl class="review_box" style={{cursor: 'pointer'}}><dt>Best Review</dt><dd>제가 여자라 그런진 몰라도 여자들에게 좀 더 공감가는 이야기인것 같아요. 첫사랑 풋사랑 아름다운 영화였습니다. 근데 영화관에서 매너 없는 분들 제발 예의 지켰으면 좋겠습니다. 계속 앞자리 발로 치고,영화상영 내내 비닐소리라니..djfskfjskdfjskldjfkdjfksjfksjdfksjdkfsjkfjsdkfjslkjfsklj</dd></dl>
                        <div className='btn_box'>
                            <a href="#none" class="btn_col3 ty2 rnd">
                                <span class="txt_ic_booking">예매하기</span>
                            </a>
                        </div>
                    </li>
                    <li style={{display: 'block'}}>
                        <div className='poster' style={{cursor: 'pointer'}}>
                        <a href="#none"><img src={movie3} alt="" style={{ width: '100%', height: 'auto' }} /></a>
                        </div>
                        <strong className='tit' style={{cursor: 'pointer'}}>
                            <span className='ic_grade gr_19'></span>
                            &nbsp;
                            더 킬러스
                        </strong>
                        <div className='detail_info ty1'>
                        <i onClick={() => { handleClick() }} >
                            {isLiked 
                                ? <FcLike style={{ width: '20px', height: '20px' }}/> 
                                : <FcLikePlaceholder style={{ width: '20px', height: '20px' }}/>}
                        </i>
                        </div>
                        <div className='btn_box'>
                            <a href="#none" class="btn_col3 ty2 rnd">
                                <span class="txt_ic_booking">예매하기</span>
                            </a>
                        </div>
                    </li>
                    <li style={{display: 'block'}}>
                        <div className='poster' style={{cursor: 'pointer'}}>
                        <a href="#none"><img src={movie2} alt="" style={{ width: '100%', height: 'auto' }} /></a>
                        </div>
                        <strong className='tit' style={{cursor: 'pointer'}}>
                            <span className='ic_grade gr_all'></span>
                            &nbsp;
                            사랑의 하츄핑
                        </strong>
                        <div className='detail_info ty1'>
                        <i onClick={() => { handleClick() }} >
                            {isLiked 
                                ? <FcLike style={{ width: '20px', height: '20px' }}/> 
                                : <FcLikePlaceholder style={{ width: '20px', height: '20px' }}/>}
                        </i>
                        </div>
                        <div className='btn_box'>
                            <a href="#none" class="btn_col3 ty2 rnd">
                                <span class="txt_ic_booking">예매하기</span>
                            </a>
                        </div>
                    </li>
                    <li style={{display: 'block'}}>
                        <div className='poster' style={{cursor: 'pointer'}}>
                        <a href="#none"><img src={movie4} alt="" style={{ width: '100%', height: 'auto' }} /></a>
                        </div>
                        <strong className='tit' style={{cursor: 'pointer'}}>
                            <span className='ic_grade gr_12'></span>
                            &nbsp;
                            세상 참 예쁜 오드리
                        </strong>
                        <div className='detail_info ty1'>
                        <i onClick={() => { handleClick() }} >
                            {isLiked 
                                ? <FcLike style={{ width: '20px', height: '20px' }}/> 
                                : <FcLikePlaceholder style={{ width: '20px', height: '20px' }}/>}
                        </i>
                        </div>
                        <div className='btn_box'>
                            <a href="#none" class="btn_col3 ty2 rnd">
                                <span class="txt_ic_booking">예매하기</span>
                            </a>
                        </div>
                    </li>
                    </ul>
                </div>
            </div>
        </>
    );
};

export default Wishes;
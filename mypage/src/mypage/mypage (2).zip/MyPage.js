import React, { useEffect, useState } from 'react';
import './style.css'
import { VscEdit } from "react-icons/vsc";
import Wishes from './Wishes';
import axios from 'axios';
import { useParams } from 'react-router-dom';



const MyPage = () => {

    const [showWishes,setShowWishes] = useState(false);

    const{userId} = useParams();

    const [customerInfo, setCustomerInfo] = useState(null);
    
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchMyPageData = async () => {
            setIsLoading(true);
                try {
                    const response = await axios.get(`/sallybox/mypage/${userId}`);
                    setCustomerInfo(response.data.customerInfo);
                    setError(null);
                } catch (err) {
                    setError('데이터를 불러오는 데 실패했습니다.');
                    console.error('Error fetching data:', err);
                } finally {
                    setIsLoading(false);
                }
            };

        fetchMyPageData();
        }, [userId]);

        if (isLoading) {
        return <div>로딩 중...</div>;
        }

        if (error) {
        return <div>에러: {error}</div>;
        }
    

    return (
        <div id='contents' className='contents_mypage' style={{ paddingTop: '50px' }}>            
            <div className='mypage_top_infor' id='mypage_top_infor'>
            <h2 className='hidden'>마이페이지</h2>
                <div className='mypage_box'>
                    <div className='my_info'>
                        <div className='grade_area'>
                            <span className='round-button m15'>{customerInfo?.grade}</span>
                        </div>
                        <p className='name'><strong>{customerInfo?.nickname}님</strong>반가워요!</p>
                        <div className='profile_set'>
                            <button type='button' className='btn_txt_edit'><VscEdit />편집</button>
                        </div>                       
                    </div>
                    <div className='btn_wrap'>
                        <p target="_blank" title="L.POINT 페이지 이동">
                            <span className='txt_img'>
                                <span style={{fontWeight:'bold'}} >S.POINT</span>
                            </span>
                            <em>{customerInfo?.points}P</em>
                        </p>
                    </div>
                </div>
            </div>
            <div id="mypage_top_menu">
                <ul className='tab_wrap_lnk ' >
                    <li className='menu-item'>
                        <h4>결제내역</h4>
                        <ul className='submenu'>
                            <li onClick={() => setShowWishes(true) }>예매내역</li>         
                        </ul>
                    </li>
                    <li className='menu-item' >
                        <h4> My 무비로그</h4>
                        <ul className='submenu'>
                            <li onClick={() => setShowWishes(true)} userId={userId}>찜하기</li>      
                        </ul>
                    </li>
                    <li className='menu-item' >
                        <h4>My 정보관리</h4>
                        <ul className='submenu'>
                            <li>회원 정보 관리</li>         
                        </ul>
                    </li>
                    <hr className="wrap_nav_underline">
                        
                    </hr>
                    {/* {wishlistMovies.map((movie) => (
  <div key={movie.movie_id}>
    <h3>{movie.title}</h3>
    <img src={`https://image.tmdb.org/t/p/original/${movie.poster_path}`}  alt={movie.title} />
    <p>{movie.overview}</p>
    <p>등급: {movie.certification}</p>
  </div>
))} */}
                    
                   
                    
                </ul>
            </div>  
            {showWishes && <Wishes />}
        </div>
    );
};

export default MyPage;